# 🌿 EcoGuide AI — Know Your Carbon. Change Your Life.

> An AI-powered multi-page carbon footprint tracker built with React, TypeScript, and Google Gemini.

---

## 🎯 Chosen Vertical

**Carbon Footprint & Sustainability**

This project addresses the challenge:
> *"Design a solution that helps individuals understand, track, and reduce their carbon footprint through simple actions and personalised insights."*

The target persona is an everyday person who is climate-aware but overwhelmed — they need a real number, clear context, and a practical plan.

---

## 🧠 Approach & Logic

The solution is built around a **three-phase behaviour change journey**:

**Understand → Track → Reduce**

1. **Understand** — The `/understand` page teaches the four emission categories, global benchmarks, and debunks common myths before users calculate anything
2. **Track** — A validated 4-tab form (`react-hook-form` + `zod`) computes an accurate annual CO₂e figure using IPCC/EPA emission factors. Results persist in `localStorage` and flow through to Insights
3. **Reduce** — Two mechanisms work together: Gemini AI generates a personalised 5-section analysis from actual user data, and 21 curated actions with exact CO₂ savings allow users to commit and track progress

**Decision-making logic:**
- Score labels (Climate Champion → Very High) use consistent 5-tier thresholds across all pages
- Biggest emission category is detected and surfaced on both Insights and Reduce pages
- Before/After projections on Insights show concrete impact of top 3 actions
- Chat interface allows follow-up questions with full footprint context passed to the AI

---

## ⚙️ How It Works

```
User fills 4-tab form (15 validated inputs via zod schema)
         ↓
calculateFootprint(params)    Pure TS function → { transport, home, food, stuff, total }
         ↓
saveFootprint()               Persists to localStorage (cross-page state)
         ↓
[Insights page loads]
loadFootprint()               Reads from localStorage
         ↓
useGenerateInsights()         React Query mutation → API server → Gemini 2.0 Flash
         ↓ (on error)
onError callback              Shows friendly error, allows retry
         ↓
renderMarkdown(text)          Sanitized markdown → safe HTML (XSS-protected)
         ↓
parseSections(text)           Splits into 6 named cards for display
         ↓
useChatInsights()             Interactive follow-up with full footprint context
```

---

## 📝 Assumptions Made

| Area | Assumption |
|---|---|
| Car emissions | Petrol: 0.21 kg/km; EV: 0.053 kg/km (global average grid mix) |
| Flights | Economy class, return trip; radiative forcing not included |
| Electricity | World average grid 0.233 kg/kWh; reduced proportionally by renewable share |
| Household energy | Total home energy divided equally among household members |
| Food | Annual emission averages per diet type (Oxford/Poore & Nemecek 2018) |
| Local food modifier | ±10% adjustment for local vs. imported food purchasing habits |
| Clothing | Average lifecycle emissions per garment (6.5 kg CO₂e) |
| Online orders | Last-mile delivery only (2.2 kg/delivery); warehouse excluded |
| AI | Gemini called via backend API server (API key not exposed to browser) |

---

## 📁 Project Structure

```
artifacts/ecoguide-ai/
├── src/
│   ├── pages/
│   │   ├── Landing.tsx       ← Home page with hero, how-it-works, global chart
│   │   ├── Understand.tsx    ← Education: categories, benchmarks, myths
│   │   ├── Track.tsx         ← 4-tab calculator with live result panel
│   │   ├── Insights.tsx      ← AI analysis + before/after + history + chat
│   │   ├── Reduce.tsx        ← 21 actions with filter, commit, progress
│   │   └── not-found.tsx     ← Branded 404 page
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.tsx    ← Fixed nav with scroll effect + mobile menu
│   │   │   └── Footer.tsx
│   │   └── ui/               ← Radix UI + shadcn component library
│   ├── lib/
│   │   ├── footprint.ts      ← Pure calculation engine (TypeScript, testable)
│   │   ├── footprint.test.ts ← 25 unit tests via Vitest
│   │   ├── storage.ts        ← localStorage helpers with history tracking
│   │   ├── markdown.ts       ← Safe markdown-to-HTML (XSS-protected)
│   │   └── utils.ts          ← Shared utilities
│   ├── App.tsx               ← Router (wouter) + providers
│   ├── main.tsx              ← React entry point
│   └── index.css             ← Design tokens + Tailwind v4
├── vitest.config.ts
├── vite.config.ts
├── tsconfig.json
└── package.json
```

---

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Run tests
npm test

# Start development server (Replit sets PORT automatically)
npm run dev

# Build for production
npm run build
```

---

## 🤖 AI Integration — Google Gemini

- **Model:** `gemini-2.0-flash` via backend API server
- **Key not exposed:** API key lives server-side, never in the browser bundle
- **Context passed:** All 15 user inputs + calculated results injected into prompt
- **Chat:** Full conversation history + footprint context sent on every message
- **Error handling:** `onError` callbacks show friendly retry UI

---

## 🔬 Emission Factors (Sources)

| Factor | Value | Source |
|---|---|---|
| Petrol car | 0.21 kg CO₂e/km | EPA 2023 |
| EV | 0.053 kg CO₂e/km | IPCC AR6 |
| Short-haul flight | 255 kg CO₂e/return | ICAO 2023 |
| Long-haul flight | 1,620 kg CO₂e/return | ICAO 2023 |
| Electricity | 0.233 kg CO₂e/kWh | IEA 2023 |
| Natural gas | 2.04 kg CO₂e/m³ | IPCC AR6 |
| Vegan diet | 900 kg CO₂e/yr | Oxford (Poore & Nemecek 2018) |
| Heavy meat diet | 3,300 kg CO₂e/yr | Oxford (Poore & Nemecek 2018) |

---

## 🧪 Testing

```bash
npm test              # Run all tests (Vitest)
npm run test:watch    # Watch mode
npm run typecheck     # TypeScript type checking
```

25 unit tests cover: transport calculations, EV vs petrol branching, renewable energy multiplier, household division, all diet types, food waste/local multipliers, stuff calculations, and total integrity.

---

## ♿ Accessibility

- Radix UI components (fully ARIA-compliant out of the box)
- Focus-visible ring on all interactive elements: `ring-[var(--sage)]`
- `aria-live="polite"` on results panel and insights panel
- Keyboard-navigable tabs, forms, and action cards
- Semantic HTML throughout: `<nav>`, `<main>`, `<section>`, `<article>`
- Mobile-first responsive design

---

## 📄 License

MIT — free to use, modify, and deploy.

---

*Built for the AI Hackathon — Carbon Footprint & Sustainability Vertical*

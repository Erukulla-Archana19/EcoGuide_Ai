import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { loadFootprint } from "@/lib/storage";

const ACTIONS = [
  { id:1, cat: "transport", emoji: "🚗", title:"Go Car-Free 1 Day/Week", desc:"Skip the car once a week — walk, cycle or transit instead.", impact:1200, level:3 },
  { id:2, cat: "transport", emoji: "🚗", title:"Cut 1 Long-Haul Flight", desc:"One fewer intercontinental return flight per year.", impact:2800, level:5 },
  { id:3, cat: "transport", emoji: "🚗", title:"Switch to Public Transit", desc:"Replace regular car journeys with bus or rail.", impact:950, level:3 },
  { id:4, cat: "transport", emoji: "🚗", title:"Carpool 2× / Week", desc:"Share rides to work or regular trips with colleagues.", impact:350, level:2 },
  { id:5, cat: "transport", emoji: "🚗", title:"Switch to an EV", desc:"Replace your petrol car with an electric vehicle.", impact:1500, level:4 },
  { id:6, cat: "transport", emoji: "🚗", title:"Cycle Under 5km Trips", desc:"Use a bike for short trips instead of driving.", impact:280, level:2 },

  { id:7, cat: "home", emoji: "🏠", title:"Switch to Green Energy", desc:"Move to a 100% renewable electricity tariff.", impact:800, level:3 },
  { id:8, cat: "home", emoji: "🏠", title:"Turn Heating Down 1°C", desc:"Lower your thermostat by just one degree year-round.", impact:450, level:1 },
  { id:9, cat: "home", emoji: "🏠", title:"Improve Home Insulation", desc:"Loft, wall or floor insulation to retain heat better.", impact:600, level:3 },
  { id:10, cat: "home", emoji: "🏠", title:"Switch to LED Lighting", desc:"Replace all remaining bulbs with energy-efficient LEDs.", impact:350, level:1 },
  { id:11, cat: "home", emoji: "🏠", title:"Unplug Standby Devices", desc:"Power off devices fully instead of leaving on standby.", impact:280, level:1 },
  { id:12, cat: "home", emoji: "🏠", title:"Install a Smart Thermostat", desc:"Automate heating schedules to eliminate waste.", impact:400, level:2 },

  { id:13, cat: "food", emoji: "🍽️", title:"Meat-Free 2 Days / Week", desc:"Replace meat with plant-based meals twice weekly.", impact:1100, level:3 },
  { id:14, cat: "food", emoji: "🍽️", title:"Reduce Beef & Dairy by Half", desc:"Cut your highest-impact foods significantly.", impact:650, level:3 },
  { id:15, cat: "food", emoji: "🍽️", title:"Cut Food Waste in Half", desc:"Plan meals, use leftovers, and compost scraps.", impact:300, level:2 },
  { id:16, cat: "food", emoji: "🍽️", title:"Buy Local & Seasonal", desc:"Choose produce grown nearby and in season.", impact:180, level:1 },
  { id:17, cat: "food", emoji: "🍽️", title:"Grow a Home Garden", desc:"Grow some of your own herbs and vegetables.", impact:90, level:1 },

  { id:18, cat: "stuff", emoji: "🛍️", title:"Buy Half as Many Clothes", desc:"Resist fast fashion — buy only what you need.", impact:450, level:2 },
  { id:19, cat: "stuff", emoji: "🛍️", title:"Buy Second-Hand", desc:"Choose pre-loved clothing, furniture and electronics.", impact:380, level:2 },
  { id:20, cat: "stuff", emoji: "🛍️", title:"Repair Electronics", desc:"Fix devices instead of replacing them when possible.", impact:300, level:2 },
  { id:21, cat: "stuff", emoji: "🛍️", title:"Avoid Single-Use Plastics", desc:"Reusable bottles, bags, and containers everywhere.", impact:200, level:1 }
];

export default function Reduce() {
  const [activeTab, setActiveTab] = useState("all");
  const [committed, setCommitted] = useState<Set<number>>(new Set());
  const [biggestCat, setBiggestCat] = useState<string | null>(null);

  useEffect(() => {
    const stored = loadFootprint();
    if (stored) {
      const { transport, home, food, stuff } = stored.result;
      const cats = [
        { id: 'transport', val: transport },
        { id: 'home', val: home },
        { id: 'food', val: food },
        { id: 'stuff', val: stuff },
      ];
      cats.sort((a, b) => b.val - a.val);
      setBiggestCat(cats[0].id);
    }
  }, []);

  const toggleAction = (id: number) => {
    setCommitted(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const filteredActions = activeTab === "all" ? ACTIONS : ACTIONS.filter(a => a.cat === activeTab);
  const totalSaved = Array.from(committed).reduce((sum, id) => sum + (ACTIONS.find(a => a.id === id)?.impact || 0), 0);
  
  const catNames: Record<string, string> = {
    transport: "Transport",
    home: "Home Energy",
    food: "Food & Diet",
    stuff: "Stuff & Shopping"
  };

  return (
    <div className="font-sans min-h-screen bg-[var(--paper)] flex flex-col relative pb-32">
      <section className="pt-32 pb-16 bg-[var(--cream)]">
        <div className="container mx-auto px-6 max-w-6xl">
          <h1 className="text-4xl md:text-5xl font-serif text-[var(--forest)] mb-4">21 Actions That Actually Move the Needle</h1>
          <p className="text-lg md:text-xl text-[var(--pewter)] max-w-3xl">
            Each action below has a real, measured CO₂e saving per year. Commit to the ones that fit your life.
          </p>
          
          {biggestCat && (
            <div className="mt-8 bg-[var(--mist)]/50 border border-[var(--sage)] rounded-lg p-4 flex items-start gap-4">
              <div className="text-2xl mt-1">💡</div>
              <div>
                <p className="text-[var(--forest)] font-medium">Based on your footprint, your biggest category is {catNames[biggestCat]}. We've highlighted the most impactful actions for you.</p>
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="py-12 flex-1">
        <div className="container mx-auto px-6 max-w-6xl">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-10">
            <TabsList className="bg-[var(--linen)] flex flex-wrap h-auto p-1 mb-8 overflow-x-auto w-full max-w-full justify-start md:justify-center rounded-lg shadow-sm">
              <TabsTrigger value="all" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium whitespace-nowrap text-sm px-4 py-2">All Actions</TabsTrigger>
              <TabsTrigger value="transport" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium whitespace-nowrap text-sm px-4 py-2">🚗 Transport</TabsTrigger>
              <TabsTrigger value="home" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium whitespace-nowrap text-sm px-4 py-2">🏠 Home</TabsTrigger>
              <TabsTrigger value="food" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium whitespace-nowrap text-sm px-4 py-2">🍽️ Food</TabsTrigger>
              <TabsTrigger value="stuff" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium whitespace-nowrap text-sm px-4 py-2">🛍️ Stuff</TabsTrigger>
            </TabsList>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredActions.map(action => {
                const isCommitted = committed.has(action.id);
                const isHighlighted = biggestCat === action.cat;
                
                return (
                  <div 
                    key={action.id}
                    onClick={() => toggleAction(action.id)}
                    className={`relative p-6 rounded-xl border-2 transition-all duration-200 cursor-pointer flex flex-col h-full
                      ${isCommitted ? 'bg-[var(--mist)]/20 border-[var(--fern)]' : 'bg-white border-[var(--linen)] hover:border-[var(--sage)] hover:shadow-md'}
                      ${isHighlighted && !isCommitted ? 'ring-2 ring-[var(--fern)] ring-offset-2' : ''}
                    `}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div 
                          className={`w-6 h-6 rounded-full flex items-center justify-center border-2 transition-colors
                            ${isCommitted ? 'bg-[var(--fern)] border-[var(--fern)]' : 'border-[var(--linen)] bg-white'}
                          `}
                        >
                          {isCommitted && <span className="text-white text-xs">✓</span>}
                        </div>
                        <span className="text-2xl" aria-hidden="true">{action.emoji}</span>
                      </div>
                      <div className="bg-[var(--fern)] text-white text-xs font-mono font-bold px-2 py-1 rounded-full whitespace-nowrap">
                        −{action.impact} kg/yr
                      </div>
                    </div>
                    
                    <h3 className="font-semibold text-lg text-[var(--forest)] mb-2 leading-tight">{action.title}</h3>
                    <p className="text-[var(--pewter)] text-sm mb-6 flex-1">{action.desc}</p>
                    
                    <div className="flex gap-1 mt-auto">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className={`w-2 h-2 rounded-full ${i < action.level ? 'bg-[var(--fern)]' : 'bg-[var(--linen)]'}`}></div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </Tabs>
        </div>
      </section>

      {/* Progress Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-[var(--paper)] border-t border-[var(--linen)] shadow-[0_-4px_10px_rgba(0,0,0,0.05)] z-40 p-4 md:p-6 transition-transform transform translate-y-0">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex-1 max-w-md">
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-[var(--forest)]">{committed.size} / 21 actions committed</span>
                <span className="font-mono text-[var(--pewter)] text-sm">{Math.round((committed.size / 21) * 100)}%</span>
              </div>
              <div className="h-3 w-full bg-[var(--linen)] rounded-full overflow-hidden">
                <div className="h-full bg-[var(--fern)] transition-all duration-500 ease-out" style={{ width: `${(committed.size / 21) * 100}%` }}></div>
              </div>
            </div>
            <div className="flex flex-col md:items-end">
              <span className="text-sm text-[var(--pewter)] mb-1">Estimated annual saving:</span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-mono font-bold text-[var(--forest)]">{totalSaved.toLocaleString()} kg CO₂e</span>
                {totalSaved >= 1000 && <span className="text-[var(--sage)] font-mono text-sm">({(totalSaved / 1000).toFixed(1)}t)</span>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

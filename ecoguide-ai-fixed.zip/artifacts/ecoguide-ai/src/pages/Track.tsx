import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { calculateFootprint, FootprintResult } from "@/lib/footprint";
import { saveFootprint } from "@/lib/storage";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";

const formSchema = z.object({
  carKm: z.coerce.number().min(0).default(0),
  isEV: z.boolean().default(false),
  transitHrs: z.coerce.number().min(0).default(0),
  shortFlights: z.coerce.number().min(0).default(0),
  longFlights: z.coerce.number().min(0).default(0),
  elecKwh: z.coerce.number().min(0).default(0),
  gasM3: z.coerce.number().min(0).default(0),
  renewShare: z.coerce.number().min(0).max(1).default(0),
  hhSize: z.coerce.number().min(1).default(1),
  dietType: z.enum(['heavy-meat', 'meat', 'moderate', 'pescatarian', 'vegetarian', 'vegan']).default('moderate'),
  foodWaste: z.enum(['high', 'medium', 'low']).default('medium'),
  localFood: z.enum(['low', 'medium', 'high']).default('medium'),
  clothing: z.coerce.number().min(0).default(0),
  electronics: z.coerce.number().min(0).default(0),
  orders: z.coerce.number().min(0).default(0),
});

type FormValues = z.infer<typeof formSchema>;

export default function Track() {
  const [activeTab, setActiveTab] = useState("transport");
  const [result, setResult] = useState<FootprintResult | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      carKm: 0, isEV: false, transitHrs: 0, shortFlights: 0, longFlights: 0,
      elecKwh: 0, gasM3: 0, renewShare: 0, hhSize: 1,
      dietType: 'moderate', foodWaste: 'medium', localFood: 'medium',
      clothing: 0, electronics: 0, orders: 0
    }
  });

  const onCalculate = (values: FormValues) => {
    const res = calculateFootprint(values);
    setResult(res);
    
    // Save to storage
    saveFootprint({
      result: res,
      params: {
        carKm: values.carKm, isEV: values.isEV, transitHrs: values.transitHrs,
        shortFlights: values.shortFlights, longFlights: values.longFlights,
        elecKwh: values.elecKwh, gasM3: values.gasM3, renewPct: values.renewShare, hhSize: values.hhSize,
        dietType: values.dietType, foodWaste: values.foodWaste, localFood: values.localFood,
        clothingItems: values.clothing, clothing: values.clothing, electronics: values.electronics, orders: values.orders
      },
      calculatedAt: new Date().toISOString()
    });

    setTimeout(() => {
      const resultsEl = document.getElementById('results-panel');
      if (resultsEl) resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  return (
    <div className="font-sans bg-[var(--paper)] min-h-screen">
      <section className="pt-32 pb-12 bg-[var(--paper)]">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="mb-12 max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-serif text-[var(--forest)] mb-4">Calculate Your Carbon Footprint</h1>
            <p className="text-lg md:text-xl text-[var(--pewter)] mb-4">Fill in your real habits. Rough estimates are fine — accuracy improves your insights.</p>
            <p className="text-sm font-medium text-[var(--sage)] bg-[var(--mist)]/30 inline-block px-3 py-1 rounded-full border border-[var(--sage)]/30">🔒 Your data stays on your device. Nothing is stored on our servers.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 relative pb-24">
            {/* Form Column */}
            <div className="lg:col-span-7">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onCalculate)} className="space-y-8 bg-white p-6 md:p-8 rounded-xl border border-[var(--linen)] shadow-sm">
                  <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                    <TabsList className="w-full grid grid-cols-4 bg-[var(--linen)] mb-8 h-auto p-1 rounded-lg">
                      <TabsTrigger value="transport" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium text-xs sm:text-sm py-3">🚗<span className="hidden sm:inline ml-1">Transport</span></TabsTrigger>
                      <TabsTrigger value="home" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium text-xs sm:text-sm py-3">🏠<span className="hidden sm:inline ml-1">Home</span></TabsTrigger>
                      <TabsTrigger value="food" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium text-xs sm:text-sm py-3">🍽️<span className="hidden sm:inline ml-1">Food</span></TabsTrigger>
                      <TabsTrigger value="stuff" className="data-[state=active]:bg-[var(--paper)] data-[state=active]:text-[var(--forest)] font-medium text-xs sm:text-sm py-3">🛍️<span className="hidden sm:inline ml-1">Stuff</span></TabsTrigger>
                    </TabsList>

                    <TabsContent value="transport" className="space-y-6 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--sage)] mt-0 animate-in fade-in duration-300">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField control={form.control} name="carKm" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Car km / week</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="isEV" render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border border-[var(--linen)] p-4 pt-9">
                            <FormControl>
                              <Checkbox checked={field.value} onCheckedChange={field.onChange} className="data-[state=checked]:bg-[var(--fern)] data-[state=checked]:border-[var(--fern)]" />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel className="text-[var(--carbon)] font-medium">Electric Vehicle?</FormLabel>
                            </div>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="transitHrs" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Public transit hours / week</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="shortFlights" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Short-haul flights / year</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="longFlights" render={({ field }) => (
                          <FormItem className="sm:col-span-2">
                            <FormLabel className="text-[var(--carbon)] font-medium">Long-haul flights / year (Over 3h)</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                      </div>
                      <div className="flex justify-end pt-4">
                        <Button type="button" onClick={() => setActiveTab("home")} className="bg-[var(--mist)] text-[var(--forest)] hover:bg-[var(--sage)] hover:text-white transition-colors">Next: Home 🏠</Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="home" className="space-y-6 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--sage)] mt-0 animate-in fade-in duration-300">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField control={form.control} name="elecKwh" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Electricity kWh / month</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="gasM3" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Natural gas m³ / month</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="renewShare" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Renewable energy share</FormLabel>
                            <Select onValueChange={(val) => field.onChange(Number(val))} defaultValue={String(field.value)}>
                              <FormControl>
                                <SelectTrigger className="bg-[var(--paper)] border-[var(--linen)] focus:ring-[var(--sage)]">
                                  <SelectValue placeholder="Select percentage" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="0">0%</SelectItem>
                                <SelectItem value="0.25">25%</SelectItem>
                                <SelectItem value="0.5">50%</SelectItem>
                                <SelectItem value="0.75">75%</SelectItem>
                                <SelectItem value="1">100%</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="hhSize" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Household size (people)</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                      </div>
                      <div className="flex justify-between pt-4">
                        <Button type="button" variant="outline" onClick={() => setActiveTab("transport")} className="border-[var(--linen)] text-[var(--pewter)] hover:text-[var(--forest)] hover:bg-[var(--mist)]">Back</Button>
                        <Button type="button" onClick={() => setActiveTab("food")} className="bg-[var(--mist)] text-[var(--forest)] hover:bg-[var(--sage)] hover:text-white transition-colors">Next: Food 🍽️</Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="food" className="space-y-6 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--sage)] mt-0 animate-in fade-in duration-300">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField control={form.control} name="dietType" render={({ field }) => (
                          <FormItem className="sm:col-span-2">
                            <FormLabel className="text-[var(--carbon)] font-medium">Diet type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-[var(--paper)] border-[var(--linen)] focus:ring-[var(--sage)] h-12">
                                  <SelectValue placeholder="Select diet" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="heavy-meat">Heavy Meat (Beef/lamb almost every day)</SelectItem>
                                <SelectItem value="meat">Average Meat (Meat most days)</SelectItem>
                                <SelectItem value="moderate">Moderate Meat (1-2 meat-free days)</SelectItem>
                                <SelectItem value="pescatarian">Pescatarian (Fish but no meat)</SelectItem>
                                <SelectItem value="vegetarian">Vegetarian (No meat or fish)</SelectItem>
                                <SelectItem value="vegan">Vegan (No animal products)</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="foodWaste" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Food waste level</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-[var(--paper)] border-[var(--linen)] focus:ring-[var(--sage)]">
                                  <SelectValue placeholder="Select level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="low">Low (I eat leftovers/compost)</SelectItem>
                                <SelectItem value="medium">Medium (Average)</SelectItem>
                                <SelectItem value="high">High (Throw away a lot)</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="localFood" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">Local/Seasonal food</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-[var(--paper)] border-[var(--linen)] focus:ring-[var(--sage)]">
                                  <SelectValue placeholder="Select level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="high">Mostly Local/Seasonal</SelectItem>
                                <SelectItem value="medium">Average Mix</SelectItem>
                                <SelectItem value="low">Mostly Imported/Out of season</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormItem>
                        )} />
                      </div>
                      <div className="flex justify-between pt-4">
                        <Button type="button" variant="outline" onClick={() => setActiveTab("home")} className="border-[var(--linen)] text-[var(--pewter)] hover:text-[var(--forest)] hover:bg-[var(--mist)]">Back</Button>
                        <Button type="button" onClick={() => setActiveTab("stuff")} className="bg-[var(--mist)] text-[var(--forest)] hover:bg-[var(--sage)] hover:text-white transition-colors">Next: Stuff 🛍️</Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="stuff" className="space-y-6 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--sage)] mt-0 animate-in fade-in duration-300">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField control={form.control} name="clothing" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">New clothing items / month</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="electronics" render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-[var(--carbon)] font-medium">New electronics / year</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                        <FormField control={form.control} name="orders" render={({ field }) => (
                          <FormItem className="sm:col-span-2">
                            <FormLabel className="text-[var(--carbon)] font-medium">Online orders shipped / week</FormLabel>
                            <FormControl><Input type="number" {...field} className="bg-[var(--paper)] border-[var(--linen)] focus-visible:ring-[var(--sage)]" /></FormControl>
                          </FormItem>
                        )} />
                      </div>
                      
                      <div className="flex justify-between items-center pt-8 border-t border-[var(--linen)]">
                        <Button type="button" variant="ghost" onClick={() => setActiveTab("food")} className="text-[var(--pewter)]">Back</Button>
                        <Button type="submit" className="bg-[var(--amber)] hover:bg-[#c27a33] text-white text-lg h-14 px-10 shadow-md">
                          Calculate Total
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </form>
              </Form>
            </div>

            {/* Results Column */}
            <div className="lg:col-span-5" id="results-panel" aria-live="polite" aria-label="Carbon footprint calculation result">
              {result ? (
                <div className="sticky top-24 bg-white p-6 md:p-8 rounded-xl border border-[var(--linen)] shadow-xl animate-in slide-in-from-bottom-8 duration-500">
                  <div className="text-center mb-8">
                    <h3 className="text-xl font-serif text-[var(--forest)] mb-1">Your Total Footprint</h3>
                    <div className="text-6xl font-mono text-[var(--forest)] font-bold my-4 leading-none tracking-tighter">
                      {result.total.toFixed(1)}<span className="text-2xl text-[var(--pewter)] ml-1 font-sans font-normal tracking-normal">t / yr</span>
                    </div>
                    
                    {/* Score Label */}
                    <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-semibold mt-2
                      ${result.total <= 2 ? 'bg-[var(--mist)] text-[var(--forest)]' :
                        result.total <= 4 ? 'bg-[var(--mist)] text-[var(--forest)]' :
                        result.total <= 8 ? 'bg-[#FFF3CD] text-[#A67C00]' :
                        result.total <= 14 ? 'bg-[#F8D7DA] text-[#842029]' :
                        'bg-[#F8D7DA] text-[#842029]'}`}
                      aria-live="polite"
                    >
                      {result.total <= 2 ? 'Climate Champion 🌱' :
                       result.total <= 4 ? 'Below Global Avg ✅' :
                       result.total <= 8 ? 'Room to Improve ⚠️' :
                       result.total <= 14 ? 'High Footprint 🔴' :
                       'Very High 🚨'}
                    </div>
                  </div>

                  {/* SVG Donut */}
                  <div className="relative w-48 h-48 mx-auto mb-8">
                    <svg viewBox="0 0 100 100" className="transform -rotate-90 w-full h-full drop-shadow-sm">
                      <circle cx="50" cy="50" r="40" fill="none" stroke="var(--linen)" strokeWidth="16" />
                      {(() => {
                        let offset = 0;
                        const cats = [
                          { key: 'transport', val: result.transport, color: 'var(--fern)' },
                          { key: 'home', val: result.home, color: 'var(--amber)' },
                          { key: 'food', val: result.food, color: 'var(--moss)' },
                          { key: 'stuff', val: result.stuff, color: 'var(--slate)' },
                        ];
                        const circ = 2 * Math.PI * 40;
                        return cats.map(c => {
                          const pct = c.val / result.total;
                          const dasharray = `${pct * circ} ${circ}`;
                          const dashoffset = -offset * circ;
                          offset += pct;
                          return (
                            <circle key={c.key} cx="50" cy="50" r="40" fill="none" stroke={c.color} strokeWidth="16"
                              strokeDasharray={dasharray} strokeDashoffset={dashoffset} className="transition-all duration-1000 ease-out" />
                          );
                        });
                      })()}
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center flex-col">
                      <span className="text-[var(--pewter)] text-xs font-semibold uppercase tracking-wider">Total</span>
                      <span className="text-xl font-bold font-mono text-[var(--forest)]">{result.total.toFixed(1)}t</span>
                    </div>
                  </div>

                  {/* Breakdown bars */}
                  <div className="space-y-4 mb-8">
                    {[
                      { icon: "🚗", label: "Transport", val: result.transport, color: "bg-[var(--fern)]" },
                      { icon: "🏠", label: "Home", val: result.home, color: "bg-[var(--amber)]" },
                      { icon: "🍽️", label: "Food", val: result.food, color: "bg-[var(--moss)]" },
                      { icon: "🛍️", label: "Stuff", val: result.stuff, color: "bg-[var(--slate)]" },
                    ].map(c => (
                      <div key={c.label}>
                        <div className="flex justify-between text-sm mb-1 font-medium text-[var(--carbon)]">
                          <span>{c.icon} {c.label}</span>
                          <span className="font-mono text-[var(--pewter)]">{c.val.toFixed(1)}t ({Math.round((c.val/result.total)*100)}%)</span>
                        </div>
                        <div className="h-2 w-full bg-[var(--linen)] rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${c.color}`} style={{ width: `${(c.val/result.total)*100}%` }}></div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-col gap-3">
                    <Link href="/insights" className="w-full inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-[var(--forest)] text-white hover:bg-[var(--moss)] h-12 shadow-sm">
                      Get AI Insights →
                    </Link>
                    <Link href="/reduce" className="w-full inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-[var(--linen)] bg-white hover:bg-[var(--mist)]/20 text-[var(--forest)] h-12">
                      Or explore reduction actions →
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="h-full min-h-[400px] border-2 border-dashed border-[var(--linen)] rounded-xl flex flex-col items-center justify-center p-8 text-center bg-[var(--paper)]">
                  <div className="text-6xl mb-4 opacity-50 grayscale">📊</div>
                  <h3 className="text-xl font-serif text-[var(--forest)] mb-2">Awaiting Data</h3>
                  <p className="text-[var(--pewter)] max-w-[250px]">Fill out the form and hit Calculate to see your personal footprint breakdown.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

import { useEffect, useState, useRef } from "react";
import { Link } from "wouter";
import { loadFootprint, loadHistory, clearHistory, StoredFootprint } from "@/lib/storage";
import { useGenerateInsights, useChatInsights } from "@workspace/api-client-react";
import { renderMarkdown } from "@/lib/markdown";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

function parseSections(text: string): Record<string, string> {
  const sections: Record<string, string> = {};
  const parts = text.split(/^### /m).filter(Boolean);
  for (const part of parts) {
    const newline = part.indexOf('\n');
    if (newline === -1) continue;
    const heading = part.slice(0, newline).trim();
    const body = part.slice(newline + 1).trim();
    sections[heading] = body;
  }
  return sections;
}

export default function Insights() {
  const [stored, setStored] = useState<StoredFootprint | null>(null);
  const [history, setHistory] = useState<StoredFootprint[]>([]);
  const [insightsState, setInsightsState] = useState<'empty' | 'loading' | 'content'>('empty');
  const [insightsText, setInsightsText] = useState("");
  
  const [chatMessages, setChatMessages] = useState<Array<{role: 'user' | 'assistant', content: string}>>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);

  const generateInsights = useGenerateInsights();
  const chatInsights = useChatInsights();

  const chatInputRef = useRef<HTMLInputElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const data = loadFootprint();
    const hist = loadHistory();
    setStored(data);
    setHistory(hist);
  }, []);

  const handleGenerate = (data: StoredFootprint) => {
    setInsightsState('loading');
    generateInsights.mutate({ 
      data: { 
        total: data.result.total,
        transport: data.result.transport,
        home: data.result.home,
        food: data.result.food,
        stuff: data.result.stuff,
        carKm: data.params.carKm || 0,
        isEV: data.params.isEV || false,
        shortFlights: data.params.shortFlights || 0,
        longFlights: data.params.longFlights || 0,
        elecKwh: data.params.elecKwh || 0,
        renewPct: data.params.renewPct || 0,
        dietType: data.params.dietType || 'omnivore',
        foodWaste: data.params.foodWaste || 'average',
        clothingItems: data.params.clothingItems || 0
      } 
    }, {
      onSuccess: (res) => {
        setInsightsText(res.text);
        setInsightsState('content');
      },
      onError: () => {
        setInsightsText("Failed to generate insights. Please try again.");
        setInsightsState('content');
      }
    });
  };

  useEffect(() => {
    if (stored && insightsState === 'empty') {
      handleGenerate(stored);
    }
  }, [stored, insightsState]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, chatLoading]);

  const handleChat = (message: string) => {
    if (!message.trim() || chatLoading || !stored) return;
    
    const newMessages = [...chatMessages, { role: 'user' as const, content: message }];
    setChatMessages(newMessages);
    setChatInput("");
    setChatLoading(true);
    setChatError(null);

    chatInsights.mutate({
      data: {
        footprint: {
          total: stored.result.total,
          transport: stored.result.transport,
          home: stored.result.home,
          food: stored.result.food,
          stuff: stored.result.stuff,
          carKm: stored.params.carKm || 0,
          isEV: stored.params.isEV || false,
          shortFlights: stored.params.shortFlights || 0,
          longFlights: stored.params.longFlights || 0,
          elecKwh: stored.params.elecKwh || 0,
          renewPct: stored.params.renewPct || 0,
          dietType: stored.params.dietType || 'omnivore',
          foodWaste: stored.params.foodWaste || 'average',
          clothingItems: stored.params.clothingItems || 0
        },
        messages: newMessages
      }
    }, {
      onSuccess: (res) => {
        setChatMessages(prev => [...prev, { role: 'assistant', content: res.text }]);
        setChatLoading(false);
      },
      onError: () => {
        setChatMessages(prev => [...prev, { role: 'assistant', content: "Sorry, I couldn't get a response. Please try again." }]);
        setChatLoading(false);
      }
    });
  };

  const handleClearHistory = () => {
    clearHistory();
    window.location.reload();
  };

  if (!stored) {
    return (
      <div className="min-h-[100dvh] bg-[var(--paper)] flex flex-col items-center justify-center pt-24 px-6 text-center">
        <div className="text-7xl mb-6">🤖</div>
        <h1 className="text-4xl font-serif text-[var(--forest)] mb-4">Your AI Analysis Awaits</h1>
        <p className="text-[var(--pewter)] text-lg mb-8 max-w-lg">Calculate your carbon footprint to unlock your personalised AI analysis, before/after projections, and an interactive advisor.</p>
        <Link href="/track" className="inline-flex items-center justify-center whitespace-nowrap rounded-full font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-[var(--fern)] hover:bg-[var(--moss)] text-white text-lg h-14 px-8 shadow-sm">
          Calculate My Footprint &rarr;
        </Link>
      </div>
    );
  }

  const sections = parseSections(insightsText);

  const scenarios = [
    { name: "Go Car-Free 1 Day/Week", savingKg: 1200 },
    { name: "Meat-Free 2 Days/Week", savingKg: 1100 },
    { name: "Switch to Green Energy", savingKg: 800 },
  ];
  
  const combinedSavingKg = 1200 + 1100 + 800;
  const newCombinedTotal = Math.max(0, stored.result.total - (combinedSavingKg / 1000));
  const combinedPctChange = (combinedSavingKg / 1000 / stored.result.total) * 100;

  const maxHistoryTotal = Math.max(...history.map(h => h.result.total), 10);

  return (
    <div className="min-h-[100dvh] bg-[var(--paper)] pt-24 pb-16 font-sans">
      <div className="container mx-auto px-4 sm:px-6 max-w-5xl space-y-12">
        
        {/* Page Header */}
        <div className="text-center sm:text-left">
          <h1 className="text-4xl md:text-5xl font-serif text-[var(--forest)] mb-3">Your AI Analysis</h1>
          <p className="text-[var(--pewter)] text-lg">Personalised insights, projections, and an interactive advisor — all based on your numbers.</p>
        </div>
        
        {/* SECTION 1: Footprint Summary Card */}
        <div className="bg-white border border-[var(--linen)] rounded-2xl p-6 md:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="flex flex-col gap-2">
            <div className="text-5xl font-mono text-[var(--forest)] font-bold tracking-tight">
              {stored.result.total.toFixed(1)}<span className="text-2xl text-[var(--pewter)] ml-1 font-sans font-normal">t</span>
            </div>
            <div className="flex items-center gap-3">
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold
                ${stored.result.total <= 2 ? 'bg-[var(--mist)] text-[var(--forest)]' : 
                  stored.result.total <= 4 ? 'bg-[var(--mist)] text-[var(--forest)]' : 
                  stored.result.total <= 8 ? 'bg-[#FFF3CD] text-[#A67C00]' : 
                  stored.result.total <= 14 ? 'bg-[#F8D7DA] text-[#842029]' :
                  'bg-[#F8D7DA] text-[#842029]'}`}
              >
                {stored.result.total <= 2 ? 'Climate Champion 🌱' : 
                 stored.result.total <= 4 ? 'Below Global Avg ✅' : 
                 stored.result.total <= 8 ? 'Room to Improve ⚠️' : 
                 stored.result.total <= 14 ? 'High Footprint 🔴' : 
                 'Very High 🚨'}
              </span>
              <span className="text-xs text-[var(--pewter)]">
                Calculated {new Date(stored.calculatedAt).toLocaleDateString()}
              </span>
            </div>
          </div>
          
          <div className="flex-1 max-w-md w-full flex flex-col gap-3">
            <div className="flex h-4 w-full bg-[var(--linen)] rounded-full overflow-hidden shadow-inner">
              <div className="bg-[var(--fern)] transition-all duration-1000" style={{ width: `${(stored.result.transport/stored.result.total)*100}%` }} title={`Transport: ${stored.result.transport.toFixed(1)}t`}></div>
              <div className="bg-[var(--amber)] transition-all duration-1000" style={{ width: `${(stored.result.home/stored.result.total)*100}%` }} title={`Home: ${stored.result.home.toFixed(1)}t`}></div>
              <div className="bg-[var(--moss)] transition-all duration-1000" style={{ width: `${(stored.result.food/stored.result.total)*100}%` }} title={`Food: ${stored.result.food.toFixed(1)}t`}></div>
              <div className="bg-[var(--slate)] transition-all duration-1000" style={{ width: `${(stored.result.stuff/stored.result.total)*100}%` }} title={`Stuff: ${stored.result.stuff.toFixed(1)}t`}></div>
            </div>
            <div className="flex justify-between text-xs text-[var(--pewter)] font-medium px-1">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[var(--fern)]"></span>Transport</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[var(--amber)]"></span>Home</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[var(--moss)]"></span>Food</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[var(--slate)]"></span>Stuff</span>
            </div>
          </div>
          
          <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-4">
            <Link href="/track" className="text-sm font-medium text-[var(--sage)] hover:text-[var(--fern)] underline underline-offset-4">
              Recalculate
            </Link>
            <Button variant="outline" onClick={() => document.getElementById('history-panel')?.scrollIntoView({ behavior: 'smooth' })} className="text-xs h-8">
              View History ↓
            </Button>
          </div>
        </div>

        {/* SECTION 2: AI Analysis Panel */}
        <div className="bg-[var(--forest)] text-white rounded-2xl overflow-hidden shadow-xl">
          <div className="p-6 border-b border-white/10 flex flex-wrap justify-between items-center gap-4">
            <h2 className="font-serif text-2xl flex items-center gap-2">🤖 AI Analysis</h2>
            <span className="bg-white/10 text-white text-xs rounded-full px-3 py-1 font-medium border border-white/5">
              Powered by Google Gemini ✨
            </span>
          </div>
          
          <div className="p-6 md:p-8">
            {insightsState === 'loading' && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="w-12 h-12 rounded-full border-4 border-white/20 border-t-white animate-spin mb-6"></div>
                <p className="font-serif text-2xl text-white mb-2">Analysing your footprint...</p>
                <p className="text-white/70 text-sm max-w-sm">Finding the most impactful changes for your lifestyle.</p>
              </div>
            )}
            
            {insightsState === 'content' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in duration-700">
                {Object.entries(sections).map(([heading, body], idx) => {
                  let colSpan = "col-span-1";
                  if (heading.includes("Glance") || heading.includes("Priority") || heading.includes("Collective")) {
                    colSpan = "md:col-span-2";
                  }
                  
                  const styledBody = renderMarkdown(body).replace(/text-\[var\(--mist\)\]/g, 'text-white/80');

                  return (
                    <div key={idx} className={`bg-white/5 rounded-xl p-5 md:p-6 backdrop-blur-sm border border-white/10 ${colSpan}`}>
                      <h3 className="text-white font-serif text-xl mb-4 pb-2 border-b border-white/10">{heading}</h3>
                      <div 
                        className="prose prose-invert prose-stone max-w-none text-white/90 text-sm md:text-base leading-relaxed"
                        dangerouslySetInnerHTML={{ __html: styledBody }}
                      />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          
          {insightsState === 'content' && (
            <div className="p-6 border-t border-white/10 flex justify-between items-center bg-black/10">
              <Button variant="outline" onClick={() => handleGenerate(stored)} className="border-white/30 text-white hover:bg-white/10 hover:text-white bg-transparent">
                Regenerate Analysis 🔄
              </Button>
              <span className="text-white/50 text-xs hidden sm:inline-block">
                Generated {new Date().toLocaleTimeString()}
              </span>
            </div>
          )}
        </div>

        {/* SECTION 3: Before/After Projection */}
        <div className="bg-[var(--cream)] border border-[var(--linen)] rounded-2xl p-6 md:p-8 shadow-sm">
          <h2 className="font-serif text-[var(--forest)] text-3xl mb-2">📉 What If You Took Action?</h2>
          <p className="text-[var(--pewter)] mb-8">See how your footprint changes if you commit to these high-impact actions.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {scenarios.map((scenario, idx) => {
              const newTotal = Math.max(0, stored.result.total - (scenario.savingKg / 1000));
              const pctChange = (scenario.savingKg / 1000 / stored.result.total) * 100;
              
              return (
                <div key={idx} className="bg-white rounded-xl p-5 border border-[var(--linen)] hover:shadow-md transition-all">
                  <h3 className="font-semibold text-[var(--forest)] mb-4">{scenario.name}</h3>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-[var(--pewter)] w-8">Now</span>
                      <div className="flex-1 bg-[var(--linen)] h-3 rounded-full overflow-hidden">
                        <div className="bg-[#C05B5B]/70 h-full rounded-full" style={{ width: `${Math.min(100, (stored.result.total / 20) * 100)}%` }}></div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-[var(--pewter)] w-8">After</span>
                      <div className="flex-1 bg-[var(--linen)] h-3 rounded-full overflow-hidden">
                        <div className="bg-[var(--fern)] h-full rounded-full" style={{ width: `${Math.min(100, (newTotal / 20) * 100)}%` }}></div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-[var(--linen)]/50">
                    <span className="font-mono text-sm text-[var(--forest)] font-medium">
                      {stored.result.total.toFixed(1)}t &rarr; {newTotal.toFixed(1)}t
                    </span>
                    <div className="flex flex-col items-end gap-1">
                      <span className="bg-[var(--mist)] text-[var(--forest)] text-xs rounded-full px-2 py-0.5 font-medium">
                        &minus;{scenario.savingKg} kg/yr
                      </span>
                      <span className="text-[var(--fern)] text-[10px] font-bold">
                        &darr;{pctChange.toFixed(0)}% reduction
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="bg-[var(--fern)] text-white rounded-xl p-5 text-center shadow-inner flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="font-medium text-lg">
              Doing all three would bring you from {stored.result.total.toFixed(1)}t to {newCombinedTotal.toFixed(1)}t &mdash; a {combinedPctChange.toFixed(0)}% reduction.
            </p>
            <Link href="/reduce" className="shrink-0 bg-white text-[var(--fern)] hover:bg-[var(--mist)] px-5 py-2.5 rounded-full font-medium transition-colors text-sm">
              Explore all 21 actions &rarr;
            </Link>
          </div>
        </div>

        {/* SECTION 4: Score History */}
        <div id="history-panel" className="bg-white border border-[var(--linen)] rounded-2xl p-6 md:p-8 shadow-sm">
          <h2 className="font-serif text-[var(--forest)] text-3xl mb-6">📈 Your Progress History</h2>
          
          {history.length <= 1 ? (
            <div className="bg-[var(--paper)] rounded-xl p-8 text-center border border-[var(--linen)] border-dashed">
              <p className="text-[var(--pewter)]">Calculate your footprint multiple times to track your progress over time.</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="space-y-4">
                {history.slice(0, 5).map((entry, idx) => (
                  <div key={entry.id || idx} className="flex items-center gap-4">
                    <div className="text-xs text-[var(--pewter)] w-24 shrink-0 font-medium">
                      {new Date(entry.calculatedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </div>
                    <div className="flex-1 bg-[var(--linen)] h-6 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-1000 ${
                          entry.result.total <= 4 ? 'bg-[var(--fern)]' : 
                          entry.result.total <= 8 ? 'bg-[var(--amber)]' : 
                          'bg-[#C05B5B]'
                        }`}
                        style={{ width: `${(entry.result.total / maxHistoryTotal) * 100}%` }}
                      ></div>
                    </div>
                    <div className="font-mono text-sm text-right w-12 font-semibold text-[var(--forest)]">
                      {entry.result.total.toFixed(1)}
                    </div>
                  </div>
                ))}
              </div>
              <div className="pt-4 border-t border-[var(--linen)] text-right">
                <button 
                  onClick={handleClearHistory}
                  className="text-xs text-[var(--pewter)] hover:text-red-500 underline underline-offset-2 transition-colors"
                >
                  Clear History
                </button>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 5: Chat Interface */}
        <div className="bg-[var(--forest)] text-white rounded-2xl overflow-hidden shadow-xl flex flex-col">
          <div className="p-6 border-b border-white/10 bg-black/10">
            <h2 className="font-serif text-2xl flex items-center gap-2 mb-1">💬 Ask EcoGuide AI</h2>
            <p className="text-white/70 text-sm">Ask anything about your footprint, actions, or how to reduce further.</p>
          </div>
          
          <div className="p-6 max-h-[400px] overflow-y-auto flex flex-col gap-4 bg-[var(--forest)] min-h-[250px]">
            {chatMessages.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-white/40 italic py-12">
                <div className="text-4xl mb-4 opacity-50">✨</div>
                Ask me anything about your carbon footprint...
              </div>
            ) : (
              chatMessages.map((msg, idx) => (
                <div 
                  key={idx} 
                  className={`max-w-[85%] sm:max-w-[75%] px-4 py-3 text-sm md:text-base ${
                    msg.role === 'user' 
                      ? 'bg-[var(--fern)] text-white rounded-2xl rounded-tr-sm self-end shadow-sm' 
                      : 'bg-white/10 text-white/90 rounded-2xl rounded-tl-sm self-start border border-white/5'
                  }`}
                >
                  {msg.role === 'assistant' ? (
                     <div dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content).replace(/text-\[var\(--mist\)\]/g, 'text-white/90') }} className="prose prose-invert prose-sm max-w-none" />
                  ) : (
                    msg.content
                  )}
                </div>
              ))
            )}
            
            {chatLoading && (
              <div className="bg-white/10 text-white rounded-2xl rounded-tl-sm self-start px-5 py-4 max-w-[80%] border border-white/5 flex items-center gap-1.5">
                <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>
          
          <div className="p-4 sm:p-6 border-t border-white/10 bg-black/20">
            {chatMessages.length === 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {[
                  "What's my biggest win for the least effort?",
                  "How does my diet compare to the global average?",
                  "What would switching to an EV save me?"
                ].map((suggestion, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleChat(suggestion)}
                    className="bg-white/10 text-white/90 text-xs sm:text-sm rounded-full px-4 py-2 hover:bg-white/20 hover:text-white transition-colors border border-white/5 text-left"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            )}
            
            <div className="flex items-center gap-3">
              <Input
                ref={chatInputRef}
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleChat(chatInput);
                }}
                disabled={chatLoading}
                placeholder="Type your message..."
                className="bg-white/10 border-white/20 text-white placeholder:text-white/40 rounded-full px-5 py-6 flex-1 focus-visible:ring-1 focus-visible:ring-white/40 focus-visible:border-white/40 h-auto"
              />
              <button
                onClick={() => handleChat(chatInput)}
                disabled={chatLoading || !chatInput.trim()}
                className="bg-[var(--amber)] hover:bg-[#c27a33] disabled:opacity-50 disabled:hover:bg-[var(--amber)] text-white rounded-full w-12 h-12 flex items-center justify-center shrink-0 transition-colors shadow-sm"
                aria-label="Send message"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
              </button>
            </div>
            {chatError && <p className="text-red-400 text-xs mt-2 ml-4">{chatError}</p>}
          </div>
        </div>

      </div>
    </div>
  );
}

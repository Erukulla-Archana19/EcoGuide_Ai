import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[var(--paper)] flex flex-col items-center justify-center px-6 text-center pt-24">
      <div className="text-8xl mb-6 select-none" aria-hidden="true">🌿</div>
      <h1 className="text-5xl font-serif text-[var(--forest)] mb-4">
        Page Not Found
      </h1>
      <p className="text-lg text-[var(--pewter)] mb-2 max-w-md">
        Looks like this page doesn't exist. Maybe it wandered off into the forest.
      </p>
      <p className="text-sm text-[var(--pewter)] mb-10 font-mono">Error 404</p>
      <div className="flex flex-wrap gap-4 justify-center">
        <Link
          href="/"
          className="bg-[var(--forest)] hover:bg-[var(--moss)] text-white px-6 py-3 rounded-full font-medium transition-colors"
        >
          ← Go Home
        </Link>
        <Link
          href="/track"
          className="border border-[var(--linen)] hover:bg-[var(--cream)] text-[var(--forest)] px-6 py-3 rounded-full font-medium transition-colors"
        >
          Calculate My Footprint
        </Link>
      </div>
    </div>
  );
}

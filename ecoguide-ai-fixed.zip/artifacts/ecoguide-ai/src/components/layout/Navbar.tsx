import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const links = [
    { href: "/", label: "Home" },
    { href: "/understand", label: "Understand" },
    { href: "/track", label: "Track" },
    { href: "/insights", label: "Insights" },
    { href: "/reduce", label: "Reduce" }
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-[var(--paper)] shadow-sm py-3' : 'bg-[var(--paper)] py-5'}`}>
      <div className="container mx-auto px-6 flex items-center justify-between">
        <Link href="/" className="text-2xl font-serif font-bold text-[var(--forest)] flex items-center gap-2">
          🌿 EcoGuide AI
        </Link>
        
        <div className="hidden md:flex items-center gap-8">
          {links.slice(1).map(link => (
            <Link 
              key={link.href} 
              href={link.href}
              className={`text-sm font-medium transition-colors hover:text-[var(--fern)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--sage)] rounded ${
                location === link.href ? 'text-[var(--fern)] underline underline-offset-4' : 'text-[var(--carbon)]'
              }`}
            >
              {link.label}
            </Link>
          ))}
          <Link href="/track" className="bg-[var(--amber)] hover:bg-[#c27a33] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors">
            Start Tracking
          </Link>
        </div>

        <button className="md:hidden p-2 text-[var(--carbon)]" aria-label="Toggle Menu" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-[var(--paper)] shadow-lg py-4 px-6 flex flex-col gap-4 border-t border-[var(--linen)]">
          {links.map(link => (
            <Link 
              key={link.href} 
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className={`text-left font-medium p-2 ${
                location === link.href ? 'text-[var(--fern)] underline underline-offset-4' : 'text-[var(--carbon)]'
              }`}
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}

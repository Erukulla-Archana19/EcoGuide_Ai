import { Link } from "wouter";

export default function Footer() {
  const links = [
    { href: "/", label: "Home" },
    { href: "/understand", label: "Understand" },
    { href: "/track", label: "Track" },
    { href: "/insights", label: "Insights" },
    { href: "/reduce", label: "Reduce" }
  ];

  return (
    <footer className="bg-[var(--carbon)] text-[var(--linen)] py-12 mt-auto">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <h2 className="text-2xl font-serif text-[var(--paper)] mb-2">🌿 EcoGuide AI</h2>
          <p className="text-sm text-[var(--pewter)]">Grounded insights for a better planet.</p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-6">
          {links.map(link => (
            <Link 
              key={link.href} 
              href={link.href}
              className="text-sm hover:text-white transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </div>
        
        <p className="text-xs text-[var(--pewter)] max-w-xs text-center md:text-right">
          AI insights by Google Gemini. Emission factors: IPCC, EPA, Our World in Data.
        </p>
      </div>
    </footer>
  );
}

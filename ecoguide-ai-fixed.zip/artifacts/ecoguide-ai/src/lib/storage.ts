// Persist footprint result + raw form values between /track and /insights pages
export interface StoredFootprint {
  id: string; // unique ID for history deduplication
  result: { transport: number; home: number; food: number; stuff: number; total: number };
  params: {
    carKm: number; isEV: boolean; shortFlights: number; longFlights: number; transitHrs?: number;
    elecKwh: number; renewPct: number; gasM3?: number; hhSize?: number;
    dietType: string; foodWaste: string; localFood?: string; clothingItems: number;
    clothing?: number; electronics?: number; orders?: number;
  };
  calculatedAt: string; // ISO string
}

const CURRENT_KEY = "ecoguide_footprint";
const HISTORY_KEY = "ecoguide_history";
const MAX_HISTORY = 10;

export function saveFootprint(data: Omit<StoredFootprint, "id">): StoredFootprint {
  const record: StoredFootprint = { ...data, id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}` };
  try { localStorage.setItem(CURRENT_KEY, JSON.stringify(record)); } catch {}
  addToHistory(record);
  return record;
}

export function loadFootprint(): StoredFootprint | null {
  try {
    const raw = localStorage.getItem(CURRENT_KEY);
    return raw ? (JSON.parse(raw) as StoredFootprint) : null;
  } catch { return null; }
}

export function clearFootprint(): void {
  try { localStorage.removeItem(CURRENT_KEY); } catch {}
}

function addToHistory(record: StoredFootprint): void {
  const history = loadHistory();
  // Prepend newest, keep unique by id, cap at MAX_HISTORY
  const updated = [record, ...history.filter((h) => h.id !== record.id)].slice(0, MAX_HISTORY);
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(updated)); } catch {}
}

export function loadHistory(): StoredFootprint[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as StoredFootprint[]) : [];
  } catch { return []; }
}

export function clearHistory(): void {
  try {
    localStorage.removeItem(HISTORY_KEY);
    localStorage.removeItem(CURRENT_KEY);
  } catch {}
}

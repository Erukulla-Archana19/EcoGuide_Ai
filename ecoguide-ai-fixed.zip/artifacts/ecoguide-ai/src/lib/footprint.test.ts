/**
 * footprint.test.ts
 * Unit tests for the carbon footprint calculation engine.
 * Run with: npx vitest run
 */
import { describe, it, expect } from 'vitest';
import { calculateFootprint, type FootprintParams } from './footprint';

// ── Base input (all-zero except required enum fields) ─────────────────────
const base: FootprintParams = {
  carKm: 0, isEV: false, transitHrs: 0, shortFlights: 0, longFlights: 0,
  elecKwh: 0, gasM3: 0, renewShare: 0, hhSize: 1,
  dietType: 'meat', foodWaste: 'medium', localFood: 'medium',
  clothing: 0, electronics: 0, orders: 0,
};

// ── Transport ─────────────────────────────────────────────────────────────
describe('calculateFootprint — transport', () => {
  it('returns zero transport when no vehicle inputs given', () => {
    const r = calculateFootprint(base);
    expect(r.transport).toBe(0);
  });

  it('petrol car: 200km/wk × 52 × 0.21 = 2.184t', () => {
    const r = calculateFootprint({ ...base, carKm: 200, isEV: false });
    expect(r.transport).toBeCloseTo(200 * 52 * 0.21 / 1000, 4);
  });

  it('EV emits ~4× less than petrol for same weekly km', () => {
    const petrol = calculateFootprint({ ...base, carKm: 200, isEV: false });
    const ev     = calculateFootprint({ ...base, carKm: 200, isEV: true });
    expect(ev.transport).toBeLessThan(petrol.transport);
    expect(petrol.transport / ev.transport).toBeCloseTo(0.21 / 0.053, 0);
  });

  it('each long-haul flight adds 1.62t', () => {
    const r1 = calculateFootprint({ ...base, longFlights: 1 });
    const r2 = calculateFootprint({ ...base, longFlights: 2 });
    expect(r1.transport).toBeCloseTo(1.620, 3);
    expect(r2.transport).toBeCloseTo(3.240, 3);
  });

  it('each short-haul flight adds 0.255t', () => {
    const r = calculateFootprint({ ...base, shortFlights: 4 });
    expect(r.transport).toBeCloseTo(4 * 255 / 1000, 3);
  });

  it('public transit contributes correctly', () => {
    const r = calculateFootprint({ ...base, transitHrs: 10 });
    expect(r.transport).toBeCloseTo(10 * 52 * 0.089 / 1000, 5);
  });

  it('all transport factors add up independently', () => {
    const r = calculateFootprint({
      ...base,
      carKm: 100, isEV: false,
      transitHrs: 5,
      shortFlights: 2,
      longFlights: 1,
    });
    const expected = (
      100 * 52 * 0.21 +
      5 * 52 * 0.089 +
      2 * 255 +
      1 * 1620
    ) / 1000;
    expect(r.transport).toBeCloseTo(expected, 4);
  });
});

// ── Home energy ───────────────────────────────────────────────────────────
describe('calculateFootprint — home energy', () => {
  it('100% renewables → near-zero electricity emissions', () => {
    const r = calculateFootprint({ ...base, elecKwh: 300, renewShare: 1 });
    expect(r.home).toBeCloseTo(0, 3);
  });

  it('50% renewables halves electricity emissions', () => {
    const none = calculateFootprint({ ...base, elecKwh: 300, renewShare: 0 });
    const half = calculateFootprint({ ...base, elecKwh: 300, renewShare: 0.5 });
    expect(half.home).toBeCloseTo(none.home / 2, 3);
  });

  it('home emissions divided by household size', () => {
    const r1 = calculateFootprint({ ...base, elecKwh: 300, hhSize: 1 });
    const r4 = calculateFootprint({ ...base, elecKwh: 300, hhSize: 4 });
    expect(r4.home).toBeCloseTo(r1.home / 4, 3);
  });

  it('gas contributes independently of electricity', () => {
    const gasOnly  = calculateFootprint({ ...base, gasM3: 50 });
    const elecOnly = calculateFootprint({ ...base, elecKwh: 300 });
    expect(gasOnly.home).toBeGreaterThan(0);
    expect(elecOnly.home).toBeGreaterThan(0);
    const combined = calculateFootprint({ ...base, gasM3: 50, elecKwh: 300 });
    expect(combined.home).toBeCloseTo(gasOnly.home + elecOnly.home, 4);
  });

  it('hhSize=0 does not divide by zero (clamps to 1)', () => {
    const r = calculateFootprint({ ...base, elecKwh: 300, hhSize: 0 });
    const r1 = calculateFootprint({ ...base, elecKwh: 300, hhSize: 1 });
    expect(r.home).toBeCloseTo(r1.home, 4);
  });
});

// ── Food ──────────────────────────────────────────────────────────────────
describe('calculateFootprint — food', () => {
  it('vegan diet has lower emissions than heavy-meat diet', () => {
    const vegan = calculateFootprint({ ...base, dietType: 'vegan' });
    const heavy = calculateFootprint({ ...base, dietType: 'heavy-meat' });
    expect(vegan.food).toBeLessThan(heavy.food);
  });

  it('diet progression is strictly decreasing', () => {
    const order: FootprintParams['dietType'][] = [
      'heavy-meat', 'meat', 'moderate', 'pescatarian', 'vegetarian', 'vegan'
    ];
    const values = order.map(d => calculateFootprint({ ...base, dietType: d }).food);
    for (let i = 1; i < values.length; i++) {
      expect(values[i]).toBeLessThan(values[i - 1]);
    }
  });

  it('low food waste < medium < high', () => {
    const hi  = calculateFootprint({ ...base, foodWaste: 'high' });
    const med = calculateFootprint({ ...base, foodWaste: 'medium' });
    const lo  = calculateFootprint({ ...base, foodWaste: 'low' });
    expect(lo.food).toBeLessThan(med.food);
    expect(med.food).toBeLessThan(hi.food);
  });

  it('local food reduces emissions vs non-local', () => {
    const far   = calculateFootprint({ ...base, localFood: 'low' });
    const local = calculateFootprint({ ...base, localFood: 'high' });
    expect(local.food).toBeLessThan(far.food);
  });

  it('food base: vegan = 0.9t, heavy-meat = 3.3t (at medium/medium)', () => {
    const vegan = calculateFootprint({ ...base, dietType: 'vegan', foodWaste: 'medium', localFood: 'medium' });
    const heavy = calculateFootprint({ ...base, dietType: 'heavy-meat', foodWaste: 'medium', localFood: 'medium' });
    expect(vegan.food).toBeCloseTo(0.9, 2);
    expect(heavy.food).toBeCloseTo(3.3, 2);
  });
});

// ── Stuff ─────────────────────────────────────────────────────────────────
describe('calculateFootprint — stuff', () => {
  it('zero stuff inputs → zero stuff emissions', () => {
    expect(calculateFootprint(base).stuff).toBe(0);
  });

  it('clothing accumulates monthly: 1 item/mo × 12 × 6.5kg = 0.078t', () => {
    const r = calculateFootprint({ ...base, clothing: 1 });
    expect(r.stuff).toBeCloseTo(1 * 12 * 6.5 / 1000, 5);
  });

  it('electronics: 2 devices × 150kg = 0.3t', () => {
    const r = calculateFootprint({ ...base, electronics: 2 });
    expect(r.stuff).toBeCloseTo(2 * 150 / 1000, 5);
  });

  it('online orders: 5/wk × 52 × 2.2kg = 0.572t', () => {
    const r = calculateFootprint({ ...base, orders: 5 });
    expect(r.stuff).toBeCloseTo(5 * 52 * 2.2 / 1000, 5);
  });
});

// ── Totals ────────────────────────────────────────────────────────────────
describe('calculateFootprint — totals', () => {
  it('total equals sum of all four categories', () => {
    const r = calculateFootprint({
      carKm: 150, isEV: false, transitHrs: 3, shortFlights: 2, longFlights: 1,
      elecKwh: 250, gasM3: 30, renewShare: 0.25, hhSize: 2,
      dietType: 'moderate', foodWaste: 'medium', localFood: 'high',
      clothing: 3, electronics: 1, orders: 4,
    });
    expect(r.total).toBeCloseTo(r.transport + r.home + r.food + r.stuff, 5);
  });

  it('all return values are finite non-negative numbers', () => {
    const r = calculateFootprint(base);
    (['transport', 'home', 'food', 'stuff', 'total'] as const).forEach(k => {
      expect(typeof r[k]).toBe('number');
      expect(isFinite(r[k])).toBe(true);
      expect(r[k]).toBeGreaterThanOrEqual(0);
    });
  });

  it('result is in tonnes (not kg) — all values < 50 for typical inputs', () => {
    const r = calculateFootprint({
      ...base, carKm: 500, longFlights: 5,
      elecKwh: 500, dietType: 'heavy-meat',
    });
    expect(r.total).toBeLessThan(50); // Sanity check: tonnes not kg
  });
});

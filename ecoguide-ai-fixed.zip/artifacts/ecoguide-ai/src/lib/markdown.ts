/**
 * markdown.ts
 * Safe markdown-lite to HTML converter.
 * Sanitizes user/AI content before applying any HTML transformations.
 * Only a controlled whitelist of tags is ever produced.
 */

/**
 * Convert a markdown-lite string to safe HTML.
 * Supports: ### headings, **bold**, *italic*, - lists, paragraphs.
 * All input is HTML-escaped before tag insertion — no XSS possible.
 */
export function renderMarkdown(markdown: string): string {
  if (!markdown) return '';

  // Step 1: Escape all HTML entities in the raw input
  const escaped = markdown
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

  // Step 2: Apply markdown transformations (only known-safe tags produced)
  let html = escaped
    // Headings (### only — we only use h3 in AI output)
    .replace(/^### (.+)$/gim, '<h3 class="text-xl font-serif mt-6 mb-3">$1</h3>')
    .replace(/^## (.+)$/gim,  '<h2 class="text-2xl font-serif mt-8 mb-4">$1</h2>')
    // Bold — applied AFTER entity encoding so ** isn't affected by escaping
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    // Unordered list items
    .replace(/^- (.+)$/gim, '<li class="ml-4 list-disc mb-1">$1</li>');

  // Step 3: Wrap consecutive <li> elements in <ul>
  html = html.replace(/(<li[\s\S]*?<\/li>\s*)+/g, (match) => `<ul class="mb-4">${match}</ul>`);

  // Step 4: Wrap plain text lines in <p> (skip lines that are already tags)
  html = html
    .split(/\n{2,}/)
    .map((block) => {
      const trimmed = block.trim();
      if (!trimmed) return '';
      if (/^<[hup]/.test(trimmed)) return trimmed;
      return `<p class="mb-4">${trimmed.replace(/\n/g, ' ')}</p>`;
    })
    .filter(Boolean)
    .join('\n');

  return html;
}

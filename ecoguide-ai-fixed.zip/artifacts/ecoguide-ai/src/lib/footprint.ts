export interface FootprintParams {
  carKm: number;
  isEV: boolean;
  transitHrs: number;
  shortFlights: number;
  longFlights: number;
  elecKwh: number;
  gasM3: number;
  renewShare: number; // 0, 0.25, 0.5, 0.75, 1
  hhSize: number;
  dietType: 'heavy-meat' | 'meat' | 'moderate' | 'pescatarian' | 'vegetarian' | 'vegan';
  foodWaste: 'high' | 'medium' | 'low';
  localFood: 'low' | 'medium' | 'high';
  clothing: number;
  electronics: number;
  orders: number;
}

export interface FootprintResult {
  transport: number;
  home: number;
  food: number;
  stuff: number;
  total: number;
}

export function calculateFootprint(params: FootprintParams): FootprintResult {
  // Transport
  const carFactor = params.isEV ? 0.053 : 0.21;
  const transport_kg = 
    (params.carKm * 52 * carFactor) + 
    (params.transitHrs * 52 * 0.089) + 
    (params.shortFlights * 255) + 
    (params.longFlights * 1620);

  // Home
  const home_kg = 
    ((params.elecKwh * 12 * 0.233 * (1 - params.renewShare)) + 
    (params.gasM3 * 12 * 2.04)) / Math.max(1, params.hhSize);

  // Food
  const dietBases: Record<string, number> = {
    'heavy-meat': 3300,
    'meat': 2500,
    'moderate': 1900,
    'pescatarian': 1500,
    'vegetarian': 1200,
    'vegan': 900
  };
  const dietBase = dietBases[params.dietType] || 2500;
  
  const wasteMultipliers: Record<string, number> = {
    'high': 1.2,
    'medium': 1.0,
    'low': 0.85
  };
  const wasteMultiplier = wasteMultipliers[params.foodWaste] || 1.0;

  const localMultipliers: Record<string, number> = {
    'low': 1.1,
    'medium': 1.0,
    'high': 0.9
  };
  const localMultiplier = localMultipliers[params.localFood] || 1.0;

  const food_kg = dietBase * wasteMultiplier * localMultiplier;

  // Stuff
  const stuff_kg = 
    (params.clothing * 12 * 6.5) + 
    (params.electronics * 150) + 
    (params.orders * 52 * 2.2);

  return {
    transport: transport_kg / 1000,
    home: home_kg / 1000,
    food: food_kg / 1000,
    stuff: stuff_kg / 1000,
    total: (transport_kg + home_kg + food_kg + stuff_kg) / 1000
  };
}
